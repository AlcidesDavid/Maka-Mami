<?php
include 'conexao.php';

$data = json_decode(file_get_contents('php://input'), true);

if($_SERVER['REQUEST_METHOD'] === 'POST' && $data){
    $selectAgre = $data['selectAgre'] ?? '';
    $data_obs = $data['data_obs'] ?? '';
    $endereco = $data['endereco'] ?? '';
    $problema = $data['problema'] ?? '';
    $agressor = $data['agressor'] ?? '';
    $vitima = $data['vitima'] ?? '';
    $testemunha = $data['testemunha'] ?? '';
    $atendimento = $data['atendimento'] ?? '';
    $evidencia = $data['evidencia'] ?? ''; 

    if(empty($selectAgre)|| empty($data_obs) || empty($endereco) || empty($problema)){
        echo json_encode(["erro" => "Data, endereço e descrição do problema são obrigatórios."]);
        exit;
    }
    $stmt = $mysqli->prepare("INSERT INTO agre(selectAgre, data_obs, endereco, problema, agressor, vitima, testemunha, atendimento, evidencia) VALUES (?, ?, ?, ?, ?, ?, ?, ?,?)");
    $stmt->bind_param("sssssssss", $selectAgre, $data_obs, $endereco, $problema, $agressor, $vitima, $testemunha, $atendimento, $evidencia);
    if($stmt->execute()){

        echo json_encode(["mensagem" => "Denúncia de agressão registrada com sucesso!"]);
    } else {
        echo json_encode(["erro" => "Erro ao salvar no banco: " . $stmt->error]);
    }

    $stmt->close();
}

$mysqli->close();
?>
