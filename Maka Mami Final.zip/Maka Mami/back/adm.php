<?php
include 'conexao.php';

    $categorias = ['infra', 'ilumina', 'agre'];
    $totalCategorias = count($categorias);

    $resInfra = $mysqli->query("SELECT COUNT(*) as total FROM infra");
    $totalInfra = $resInfra->fetch_assoc()['total'];


    $resIlumina = $mysqli->query("SELECT COUNT(*) as total FROM ilumina");
    $totalIlumina = $resIlumina->fetch_assoc()['total'];

    
    $resAgre = $mysqli->query("SELECT COUNT(*) as total FROM agre");
    $totalAgre = $resAgre->fetch_assoc()['total'];


?>