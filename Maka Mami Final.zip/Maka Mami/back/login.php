<?php
header('Content-Type: application/json');
session_start();
require_once 'conexao.php';

$dados = json_decode(file_get_contents('php://input'), true);
$emailSave = $dados['email'] ?? '';
$senhaSave = $dados['senha'] ?? '';

$sql = "SELECT id, nome, senha FROM adm Where email = ? LIMIT 1";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $emailSave);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if($usuario && password_verify($senhaSave, $usuario['senha'])){
    $_SESSION['adm_id'] = $usuario['id'];
    $_SESSION['adm_nome'] = $usuario['nome'];
    echo json_encode(["sucesso"=>true]);
} else{
echo json_encode(["sucesso" => false, "erro"=> "E-mail ou senha incorretas"]);
    }


?>