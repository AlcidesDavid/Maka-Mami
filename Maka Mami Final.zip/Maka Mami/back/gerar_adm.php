<?php
require_once 'conexao.php';

    $email = "alcidesd832@gmail.com";
    $nome = "Alcides";
    $senha_pura = "senha123";
    $senha_hash = password_hash($senha_pura, PASSWORD_DEFAULT);

    $sql = "INSERT INTO adm (email, nome, senha) VALUES (?,?,?)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("sss", $email, $nome, $senha_hash);

    if($stmt->execute()){
        echo "Administrador criado com sucesso!";
    }else{
        echo "Erro: ".$mysqli->error;
    }

?>