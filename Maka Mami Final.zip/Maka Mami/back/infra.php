<?php
include 'conexao.php';
$data = json_decode(file_get_contents('php://input'), true);

if($_SERVER['REQUEST_METHOD'] === 'POST' && $data){
    $nome = $data['nome'] ?? '';
    $sobrenome = $data['sobrenome'] ?? '';
    $selecInfra = $data['selecInfra'] ?? '';
    $radio = $data['radio'] ?? '';
    $desc = $data['desc'] ?? '';
    $endereco = $data['endereco'] ?? '';
    $ref = $data['ref'] ?? '';
    $nomeArquivo = $data['nomeArquivo'] ?? '';
    $IMG = $data['IMG'] ?? '';
    $rec = $data['rec'] ?? '';


    if(empty($selecInfra) || empty($radio) || empty($desc) || empty($endereco) || empty($IMG)|| empty($rec)){
        echo json_encode(["erro" => "Todos os campos são obrigatórios."]);
        exit;
    }

    $stmt = $mysqli->prepare("INSERT INTO infra (nome, sobrenome, selectInfra, radio, descricao, endereco, ref, nomeArquivo, IMG, rec) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("ssssssssss",$nome, $sobrenome, $selecInfra, $radio, $desc, $endereco, $ref, $nomeArquivo, $IMG, $rec);
    
    if($stmt->execute()){
        echo json_encode(["mensagem" => "Denúncia de infraestrutura cadastrada!"]);
    } else {
        echo json_encode(["erro" => "Erro ao salvar no banco: " . $stmt->error]);
    }
    $stmt->close();

}
$mysqli->close();
?>
