<?php
include 'conexao.php';
$data = json_decode(file_get_contents('php://input'), true);

if($_SERVER['REQUEST_METHOD'] === 'POST' && $data){
    $nome = $data['nome'] ?? '';
    $sobrenome = $data['sobrenome'] ?? '';
    $endereco = $data['endereco'] ?? '';
    $ref = $data['ref'] ?? '';
    $nif = $data['nif'] ?? '';
    $selectL = $data['selectL'] ?? '';
    $danos = $data['danos'] ?? '';
    $nomeArquivo = $data['nomeArquivo'] ?? ''; 
    $IMG = $data['IMG'] ?? '';

    if(empty($endereco) || empty($ref) || empty($nif) || empty($selectL) || empty($danos) || empty($nomeArquivo) || empty($IMG)){
        echo json_encode(["erro" => "Todos os campos são obrigatórios."]);
        exit;
    }

    $stmt = $mysqli->prepare("INSERT INTO ilumina (nome, sobrenome, endereco, ref, nif, selectL, danos, nomeArquivo, IMG) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssss", $nome, $sobrenome, $endereco, $ref, $nif, $selectL, $danos, $nomeArquivo, $IMG);
    
    if($stmt->execute()){
        echo json_encode(["mensagem" => "Denúncia de iluminação cadastrada com sucesso!"]);
    } else {
        echo json_encode(["erro" => "Erro ao cadastrar no banco de dados.". $stmt->error]);
    }
    $stmt->close();
}
$mysqli->close();
?>
