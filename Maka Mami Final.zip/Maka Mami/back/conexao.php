<?php
$hostname= "localhost";
$db= "db_maka";
$usuario = "root";
$senhas= "";

$mysqli = new mysqli($hostname, $usuario, $senhas, $db);

if($mysqli->connect_error){
    die(json_encode(["erro" => "Erro na conexão: " . $mysqli->connect_error]));
}

?>