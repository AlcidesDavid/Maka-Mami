
<?php
include 'back/adm.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/Dashboard.css">
</head>
<body>

<div class="mainDiv"> 

    <nav class="Divleft">
        
    <div class="logo"><img src="./Photos/LOGO1.png" alt="" style="height: 200px;"></div>
    <section class="filhos">
<a href="home.html" class="filho2"><img src="./icons/Group 4250.png" alt=""class="icons"style="margin:6px;">Home</a>
<a href="" class="filho1"><img src="./icons/verdadeiro.png" alt=""class="icons" style="margin:7px;">Tarefas</a>
<a href="" class="filho1"><img src="./icons/notificacao.png" alt=""class="icons" style="margin:5px;">Notificações</a>
<a href="" class="filho1"><img src="./icons/team-building.png" alt=""class="icons" style="margin:5px;">Grupo Filda</a>
<a href="" class="filho1"><img src="./icons/ajuda.png" alt=""class="icons" style="margin:5px;">Ajuda</a>
<a href="back/logout.php" class="filho1"><img src="./icons/sair-do-usuario.png" alt=""class="icons" style="margin:5px;">Sair</a>
    </section>
    </nav>
    
    <section class ="Divcenter">

        <div class="Dashboard">
            <div class="First">

 <div class="mainText">
    <h1 class="letter1">DASHBOARD</h1>
    <p style="color: #333;">Planejar, Priorizar, e Cumprir com as tarefas</p>
</div>
<div class="buttons">
    <button class="btn1">Nova Denúncia</button>
    <button class="btn2">Visualizar BD</button>
</div>
            </div>

<section class="Dados">
    <div class="results1">
        <div class="infos11">Total de Resultados  <img src="icons/NEXT.png" class="icn" alt=""></div>
        <div class="infos2" style="color:white;"><?php echo $totalCategorias;?></div>
        <div class="infos3">Dados Atuais</div>
    </div>
    <div class="results">
        <div class="infos1">Tt de Infraestrutura <img src="icons/NEXT.png" class="icn" alt="" ></div>
        <p class="infos2"><?php echo $totalInfra;?></p>
        <div class="infos3">Dados Atuais</div>
    </div>
    <div class="results">
        <div class="infos1">Total de Iluminação<img src="icons/NEXT.png" alt="" class="icn"> </div>
        <p class="infos2"><?php echo $totalIlumina;?></p>
        <div class="infos3">Dados Atuais</div>
    </div>
    <a href="agreInfo.html">
    <div class="results">
        <div class="infos1">Total de Agressão<img src="icons/NEXT.png" alt="" class="icn"></div>
        <p class="infos2"><?php echo $totalAgre;?></p>
        <div class="infos3">Dados Atuais</div>
    </div>
    </a>
</section>

<section class="analise">
    <section class="part1">
    <div class="analises1">
        
        <div class="est1"><h5>TR</h5></div>
        <div class="est2"><h5>TC</h5></div>
        <div class="est3"><h5>TO</h5></div>
        <div class="est4"><h5>TL</h5></div>
    </div>
        <section class="analises11">
        <h1><strong>Portal do Munícipe</strong></h1>
        </section>
    </section>
    <section class="part2">
    <section class="sons">

        <div class="analises2">
        <p class="reminders1"><b>Notificações</b></p>
        <h3 class="reminders2">Reunião com todos os<br>Munícipes</h3>
        <div class="reminders3"><button class="btn3">Conversar</button></div>
    </div>
     <div class="analises21">
    </div>

     <div class="analises21">
    </div>
    
    </section>


</section>

</div>

</section>

</div>
    
</body>
</html>

 <script>
       /*<section class="sons">
    <div class="analises3">
        <div class="projectos1" > <b>Projetos</b><button class="add"><img src="icons/Group.png" alt="" style="height: 15px;">Novo</button></div>
        <div class="projectos"><img src="icons/Frame 17(1).png"alt=""class="frame">Sopa Solidária</div>
        <div class="projectos"><img src="icons/Frame 17.png"alt=""class="frame">Jogo Solidário</div>
        <div class="projectos"><img src="icons/Frame 17(4).png"alt=""class="frame">Doação de roupas ao Lar Kuzola</div>
        <div class="projectos"><img src="icons/Frame 17(3).png"alt=""class="frame">Palestra sobre o abandono infantil</div>
        <div class="projectos"><img src="icons/Frame 17(2).png"alt=""class="frame">Visita à lares de acolhimento</div>
    </div>
    </section>*/
 </script>